"""
app_agent/tools.py — Windows GUI automation tools (pywinauto + keyboard/mouse).

All methods return strings (success message or error string).
Designed to be called from the agentic loop in core.py.
"""
from __future__ import annotations

import subprocess
import time
from typing import Optional

try:
    import pywinauto
    from pywinauto import Desktop, Application
    from pywinauto.keyboard import send_keys
    PYWINAUTO_AVAILABLE = True
except ImportError:
    PYWINAUTO_AVAILABLE = False

# ONLY block keys that would kill the JARVIS process itself when sent to a terminal.
# Everything else is allowed — the agent can use any hotkey in any normal app.
_TERMINAL_KILL_HOTKEYS = {"ctrl+c", "ctrl+z", "ctrl+d", "ctrl+break"}

# Windows with these title substrings are terminals — never send kill hotkeys there.
_BLOCKED_WINDOW_TITLES = {
    "windows terminal", "powershell", "command prompt", "cmd.exe",
    "python", "terminal", "bash", "wsl",
}


def _is_terminal_window(title: str) -> bool:
    t = title.lower()
    return any(blocked in t for blocked in _BLOCKED_WINDOW_TITLES)


def _to_pywinauto_keys(keys: str) -> str:
    """
    Convert human-readable hotkey string to pywinauto send_keys format.
    Handles any combination — ctrl, alt, shift, win, function keys, special keys.
    Examples:
      ctrl+l       → ^l
      alt+d        → %d
      ctrl+shift+t → ^+t
      win+d        → {VK_LWIN}d
      f5           → {F5}
      enter        → {ENTER}
    """
    key_map = {
        "ctrl":   "^",
        "alt":    "%",
        "shift":  "+",
        "win":    "{VK_LWIN}",
        "enter":  "{ENTER}",
        "return": "{ENTER}",
        "escape": "{ESC}",
        "esc":    "{ESC}",
        "tab":    "{TAB}",
        "space":  " ",
        "delete": "{DELETE}",
        "del":    "{DELETE}",
        "backspace": "{BACKSPACE}",
        "bs":     "{BACKSPACE}",
        "home":   "{HOME}",
        "end":    "{END}",
        "pageup": "{PGUP}",
        "pgup":   "{PGUP}",
        "pagedown": "{PGDN}",
        "pgdn":   "{PGDN}",
        "up":     "{UP}",
        "down":   "{DOWN}",
        "left":   "{LEFT}",
        "right":  "{RIGHT}",
        "insert": "{INSERT}",
        "ins":    "{INSERT}",
        "printscreen": "{PRTSC}",
        "f1":  "{F1}",  "f2":  "{F2}",  "f3":  "{F3}",  "f4":  "{F4}",
        "f5":  "{F5}",  "f6":  "{F6}",  "f7":  "{F7}",  "f8":  "{F8}",
        "f9":  "{F9}",  "f10": "{F10}", "f11": "{F11}", "f12": "{F12}",
    }

    normalized = keys.lower().strip().replace(" ", "")
    parts = normalized.split("+")
    combo = ""
    for part in parts:
        combo += key_map.get(part, part)
    return combo


class GUIToolKit:
    def __init__(self):
        self.available = PYWINAUTO_AVAILABLE

    def execute(self, action: dict) -> str:
        if not self.available:
            return (
                "[APP AGENT] pywinauto is not installed. "
                "Install it on Windows with: pip install pywinauto\n"
                "The App Agent requires Windows with pywinauto to function."
            )

        atype = action.get("type", "").upper()
        try:
            if atype == "READ_TREE":    return self.read_tree(action.get("window", "foreground"))
            if atype == "GET_TEXT":     return self.get_text(action.get("element", ""), action.get("window", "foreground"))
            if atype == "CLICK":        return self.click(action.get("element", ""), action.get("control_type"))
            if atype == "DOUBLE_CLICK": return self.double_click(action.get("element", ""))
            if atype == "TYPE_TEXT":    return self.type_text(action.get("text", ""), action.get("element"))
            if atype == "HOTKEY":       return self.hotkey(action.get("keys", ""))
            if atype == "LAUNCH_APP":   return self.launch_app(action.get("app", ""))
            if atype == "FOCUS_WINDOW": return self.focus_window(action.get("title", ""))
            if atype == "LIST_WINDOWS": return self.list_windows()
            if atype == "SCREENSHOT":   return self.screenshot()
            if atype == "FINISH":       return f"[DONE] {action.get('summary', '')}"
            return f"[ERROR] Unknown action: {atype}"
        except Exception as e:
            return f"[ERROR] {atype} failed: {e}"

    def _get_desktop(self):
        return Desktop(backend="uia")

    def _get_foreground(self):
        """Get the current foreground window. Returns (window_obj, title) or (None, '')."""
        try:
            import ctypes
            desktop = self._get_desktop()
            hwnd = ctypes.windll.user32.GetForegroundWindow()
            wins = desktop.windows()
            for w in wins:
                try:
                    if w.handle == hwnd:
                        return w, w.window_text()
                except Exception:
                    pass
        except Exception:
            pass
        return None, ""

    def _collect_tree(self, element, lines: list, depth: int = 0, max_depth: int = 5) -> None:
        if depth > max_depth:
            return
        try:
            name = element.window_text()
            ctrl_type = element.element_info.control_type or ""
            indent = "  " * depth
            if name.strip():
                lines.append(f"{indent}[{ctrl_type}] {name.strip()}")
        except Exception:
            pass
        try:
            for child in element.children():
                self._collect_tree(child, lines, depth + 1, max_depth)
        except Exception:
            pass

    def read_tree(self, window: str = "foreground") -> str:
        desktop = self._get_desktop()

        if window.lower() == "foreground":
            target, title = self._get_foreground()
            if not target:
                return "[READ_TREE] No foreground window found."
        else:
            try:
                target = desktop.window(title_re=f".*{window}.*")
                title = target.window_text()
            except Exception:
                return f"[READ_TREE] No window matching '{window}' found."

        try:
            if _is_terminal_window(title):
                return f"[READ_TREE] '{title}' is a terminal — read-only, will not interact."

            lines = [f"Window: {title}"]

            # Try wrapper_object() first, fall back to direct element
            try:
                root = target.wrapper_object()
            except Exception:
                root = target

            self._collect_tree(root, lines, depth=0)

            if len(lines) <= 1:
                # wrapper_object fallback didn't collect children — try direct children
                try:
                    for child in target.children():
                        self._collect_tree(child, lines, depth=1)
                except Exception:
                    pass

            return "\n".join(lines[:150])
        except Exception as e:
            return f"[READ_TREE] Failed: {e}"

    def get_text(self, element: str, window: str = "foreground") -> str:
        try:
            desktop = self._get_desktop()
            if window.lower() == "foreground":
                win_obj, _ = self._get_foreground()
            else:
                win_obj = desktop.window(title_re=f".*{window}.*")

            if not win_obj:
                return "[GET_TEXT] Window not found."
            if _is_terminal_window(win_obj.window_text()):
                return "[GET_TEXT] Terminal window — read only."

            el = win_obj.child_window(title_re=f".*{element}.*")
            return f"[GET_TEXT] '{element}': {el.window_text()}"
        except Exception as e:
            return f"[GET_TEXT] Failed: {e}"

    def click(self, element: str, control_type: Optional[str] = None) -> str:
        try:
            desktop = self._get_desktop()
            win_obj, title = self._get_foreground()
            if not win_obj:
                return "[CLICK] No foreground window."
            if _is_terminal_window(title):
                return "[CLICK] Refused — target is a terminal window."

            kwargs = {"title_re": f".*{element}.*"}
            if control_type:
                kwargs["control_type"] = control_type
            el = win_obj.child_window(**kwargs)
            el.click_input()
            return f"[CLICK] Clicked '{element}'"
        except Exception as e:
            return f"[CLICK] Failed: {e}"

    def double_click(self, element: str) -> str:
        try:
            win_obj, title = self._get_foreground()
            if not win_obj:
                return "[DOUBLE_CLICK] No foreground window."
            if _is_terminal_window(title):
                return "[DOUBLE_CLICK] Refused — terminal window."
            el = win_obj.child_window(title_re=f".*{element}.*")
            el.double_click_input()
            return f"[DOUBLE_CLICK] Double-clicked '{element}'"
        except Exception as e:
            return f"[DOUBLE_CLICK] Failed: {e}"

    def type_text(self, text: str, element: Optional[str] = None) -> str:
        try:
            if element:
                self.click(element)
                time.sleep(0.2)
            send_keys(text, with_spaces=True, pause=0.03)
            preview = text[:60] + ("..." if len(text) > 60 else "")
            return f"[TYPE_TEXT] Typed: {preview!r}"
        except Exception as e:
            return f"[TYPE_TEXT] Failed: {e}"

    def hotkey(self, keys: str) -> str:
        """
        Send ANY hotkey combination. Only restriction: terminal kill keys
        (ctrl+c, ctrl+z, ctrl+d, ctrl+break) are blocked when the foreground
        window is a terminal — to prevent killing the JARVIS process itself.
        Everything else works in any application.
        """
        normalized = keys.lower().strip().replace(" ", "")

        # Check foreground window
        _, foreground_title = self._get_foreground()

        # Block terminal-killing hotkeys only when a terminal is focused
        if _is_terminal_window(foreground_title) and normalized in _TERMINAL_KILL_HOTKEYS:
            return (
                f"[HOTKEY] BLOCKED: '{keys}' would kill a process in terminal "
                f"'{foreground_title}'. Focus a different window first."
            )

        try:
            combo = _to_pywinauto_keys(keys)
            send_keys(combo)
            return f"[HOTKEY] Sent: {keys}"
        except Exception as e:
            return f"[HOTKEY] Failed: {e}"

    def launch_app(self, app: str) -> str:
        app_map = {
            "notepad":     "notepad.exe",
            "calc":        "calc.exe",
            "calculator":  "calc.exe",
            "paint":       "mspaint.exe",
            "chrome":      "chrome.exe --force-renderer-accessibility",
            "firefox":     "firefox.exe",
            "edge":        "msedge.exe",
            "code":        "code",
            "vscode":      "code",
            "word":        "winword.exe",
            "excel":       "excel.exe",
            "powerpoint":  "powerpnt.exe",
            "explorer":    "explorer.exe",
            "spotify":     "spotify.exe",
            "discord":     "discord.exe",
            "vlc":         "vlc.exe",
            "zoom":        "zoom.exe",
            "teams":       "teams.exe",
            "slack":       "slack.exe",
            "obs":         "obs64.exe",
        }
        exe = app_map.get(app.lower().strip(), app)
        try:
            subprocess.Popen(exe, shell=True)
            time.sleep(1.5)
            return f"[LAUNCH_APP] Launched: {app}"
        except Exception as e:
            return f"[LAUNCH_APP] Failed to launch '{app}': {e}"

    def focus_window(self, title: str) -> str:
        try:
            desktop = self._get_desktop()
            win = desktop.window(title_re=f".*{title}.*")
            t = win.window_text()
            if _is_terminal_window(t):
                return f"[FOCUS_WINDOW] Refused — '{t}' is a terminal."
            win.set_focus()
            time.sleep(0.4)
            return f"[FOCUS_WINDOW] Focused: {t}"
        except Exception as e:
            return f"[FOCUS_WINDOW] Failed: {e}"

    def list_windows(self) -> str:
        try:
            desktop = self._get_desktop()
            wins = desktop.windows()
            lines = []
            for w in wins:
                try:
                    title = w.window_text()
                    if title.strip():
                        flag = " [TERMINAL — hotkey kill-keys blocked]" if _is_terminal_window(title) else ""
                        lines.append(f"  • {title}{flag}")
                except Exception:
                    pass
            if not lines:
                return "[LIST_WINDOWS] No visible windows found."
            return "[LIST_WINDOWS] Open windows:\n" + "\n".join(lines[:30])
        except Exception as e:
            return f"[LIST_WINDOWS] Failed: {e}"

    def screenshot(self) -> str:
        """Returns accessibility tree of foreground window."""
        return self.read_tree("foreground")