"""
app_agent/core.py — Self-contained App Agent agentic loop.

Self-contained — no dependency on any external folder.
Uses pywinauto for Windows GUI automation.
Falls back gracefully on non-Windows environments.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from app_agent.tools import GUIToolKit
from app_agent.prompts import APP_AGENT_PROMPT
from utils.llm import call_llm
from utils.json_parser import extract_json
from utils.logger import logger

MAX_STEPS = 30


class AppAgentCore:
    """
    Autonomous GUI automation agent.
    run(task: str) → str  (result summary or error message)
    """

    def __init__(self) -> None:
        self.tools = GUIToolKit()

    def run(self, task: str) -> str:
        logger.info(f"[app-agent-core] Task: {task!r}")
        start = time.time()

        messages: list[dict] = [
            {
                "role": "user",
                "content": (
                    f"TASK: {task}\n\n"
                    "Start by listing open windows with LIST_WINDOWS, then proceed."
                ),
            }
        ]

        final_result = f"[Task incomplete after {MAX_STEPS} steps]"
        parse_failures = 0

        for step in range(1, MAX_STEPS + 1):
            print(f"[app step {step:02d}] Thinking...", end=" ", flush=True)

            try:
                raw = call_llm(APP_AGENT_PROMPT, messages, max_tokens=800)
            except Exception as exc:
                final_result = f"[LLM error at step {step}: {exc}]"
                break

            parsed = extract_json(raw)
            if not parsed:
                parse_failures += 1
                print(f"parse-error ({parse_failures}/3)")
                if parse_failures >= 3:
                    final_result = "[Agent error: 3 consecutive JSON parse failures]"
                    break
                messages.append({"role": "assistant", "content": raw})
                messages.append({
                    "role": "user",
                    "content": "Your response was not valid JSON. Reply with ONLY a single JSON object.",
                })
                continue

            parse_failures = 0
            thought = parsed.get("thought", "")
            action = parsed.get("action", {})
            done = parsed.get("done", False)
            atype = action.get("type", "?").upper()

            print(atype)
            if thought:
                print(f"         → {thought.splitlines()[0][:100]}")

            if atype == "FINISH" or done:
                final_result = action.get("summary", thought)
                print(f"\n[app-agent] ✓ COMPLETE\n{final_result}")
                break

            result = self.tools.execute(action)
            print(f"         ← {result.splitlines()[0][:90]}")

            messages.append({"role": "assistant", "content": raw})
            messages.append({"role": "user", "content": f"RESULT:\n{result[:3000]}"})

        return final_result
