def send_request_with_retry(url, max_retries=3, timeout=5):
    retries = 0
    while retries <= max_retries:
        try:
            response = requests.get(url, timeout=timeout)
            response.raise_for_status()
            return response
        except requests.exceptions.RequestException as e:
            print(f'Retry {retries+1}/{max_retries}: {e}')
            retries += 1
    print('All retries failed. Giving up.')
    return None

import requests

api_endpoint = 'http://api.open-notify.org/iss-now.json'

response = send_request_with_retry(api_endpoint, max_retries=3, timeout=5)

response_json = response.json()

iss_latitude = response_json['iss_position']['latitude']
iss_longitude = response_json['iss_position']['longitude']

print(f'ISS Latitude: {iss_latitude}, ISS Longitude: {iss_longitude}')