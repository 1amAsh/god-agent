# SUVAT Equations Simulation

def calculate_displacement(u, v, a, t):
    return u * t + 0.5 * a * t**2

def calculate_final_velocity(u, a, t):
    return u + a * t

def calculate_initial_velocity(v, a, t):
    return v - a * t

def calculate_acceleration(u, v, t):
    return (v - u) / t

def calculate_time(u, v, a):
    return (v - u) / a

# Define initial conditions and solve for unknowns
def solve_suvat_equations(u=None, v=None, a=None, t=None, s=None):
    if u is None and v is not None and a is not None and t is not None:
        u = calculate_initial_velocity(v, a, t)
    elif v is None and u is not None and a is not None and t is not None:
        v = calculate_final_velocity(u, a, t)
    elif a is None and u is not None and v is not None and t is not None:
        a = calculate_acceleration(u, v, t)
    elif t is None and u is not None and v is not None and a is not None:
        t = calculate_time(u, v, a)
    elif s is None and u is not None and a is not None and t is not None:
        s = calculate_displacement(u, v, a, t)
    return u, v, a, t, s

# Test the functions
# Get user input
u = float(input("Enter initial velocity (m/s): "))
v = float(input("Enter final velocity (m/s): "))
a = float(input("Enter acceleration (m/s^2): "))
t = float(input("Enter time (s): "))
s = float(input("Enter displacement (m): "))

# Solve SUVAT equations based on user input
if u is None and v is not None and a is not None and t is not None:
    u = calculate_initial_velocity(v, a, t)
elif v is None and u is not None and a is not None and t is not None:
    v = calculate_final_velocity(u, a, t)
elif a is None and u is not None and v is not None and t is not None:
    a = calculate_acceleration(u, v, t)
elif t is None and u is not None and v is not None and a is not None:
    t = calculate_time(u, v, a)
elif s is None and u is not None and a is not None and t is not None:
    s = calculate_displacement(u, v, a, t)
print("Initial velocity: ", u)
print("Final velocity: ", v)
print("Acceleration: ", a)
print("Time: ", t)
print("Displacement: ", s)
print(solve_suvat_equations(v=20, a=2, t=5))
print(solve_suvat_equations(u=10, a=2, t=5))
print(solve_suvat_equations(u=10, v=20, t=5))
print(solve_suvat_equations(u=10, a=2, t=5))