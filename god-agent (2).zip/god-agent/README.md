# ⚡ JARVIS — God Agent
### Multi-Agent AI Operating System

> **Not a chatbot. Not a wrapper. An AI that decides which AI to use.**

JARVIS is an autonomous orchestrator that decomposes any natural language goal into subtasks and delegates them to specialist agents — coding, research, and GUI automation — with no hardcoded routing logic. Every routing decision is made by an LLM reading agent capability cards in real time.

---

## Architecture

```
You (natural language)
        │
        ▼
┌───────────────────┐
│    GOD AGENT      │  ← LLM-powered orchestrator
│  (god_agent.py)   │    reads agent cards, decides routing
│                   │    manages memory + shared workspace
└─────────┬─────────┘
          │
    ┌─────┴──────────────────────┐
    ▼            ▼               ▼
┌────────┐  ┌──────────┐  ┌──────────┐
│RESEARCH│  │  CODING  │  │   APP    │
│ AGENT  │  │  AGENT   │  │  AGENT   │
│        │  │          │  │          │
│ search │  │write/run │  │ Windows  │
│ fetch  │  │ code     │  │ GUI auto │
│ scrape │  │ file ops │  │ UIA/vision│
└────────┘  └──────────┘  └──────────┘
    │            │               │
    └────────────┴───────────────┘
                 │
         Shared Workspace (SQLite)
         + Conversation Memory (SQLite)
```

### Task Routing Modes
| Mode | When | Example |
|------|------|---------|
| **DIRECT** | JARVIS answers from its own knowledge | "What is recursion?" |
| **SINGLE** | One agent handles it all | "Write a Python script for X" |
| **CHAIN** | Agents work sequentially, passing results | "Research an API then build a dashboard with it" |
| **PARALLEL** | Independent tasks at the same time | "Research X and organize my Downloads folder" |

### A2A (Agent-to-Agent) Context Flow
In CHAIN mode, the research agent's full output — including API endpoints, working code snippets, and data schemas — is injected as context into the coding agent. The coding agent builds from real data, not mock data.

---

## The "Mother OS" Concept

Every other project at this hackathon solves one problem in one domain.  
JARVIS is the layer that **builds those projects**.

Give JARVIS a domain: railways, logistics, weather, finance, exams.  
JARVIS will:
1. Research agent → find a working real-time data API (structured integration spec, not prose)
2. Coding agent → build a functional integration and run it
3. App agent → demonstrate or operate it on the desktop

No hardcoding. No templates. One system, every theme.

---

## Setup

### 1. Prerequisites
- Python 3.10+
- Windows (for app agent GUI automation; research + coding agents work on any OS)

### 2. Install dependencies
```bash
cd god-agent
pip install -r requirements.txt

# Windows only — GUI automation:
pip install pywinauto Pillow
```

### 3. Configure `.env`
Copy `.env` and fill in your API keys:
```
GEMINI_API_KEY=...     # get free at aistudio.google.com
GROQ_API_KEY=...       # get free at console.groq.com
SERPER_API_KEY=...     # get free at serper.dev (research agent web search)
```

### 4. Set up Ollama (local fallback — runs when cloud credits run out)
```bash
# Download Ollama from https://ollama.com, then:
ollama pull qwen2.5:1.5b        # main brain (~900MB RAM)
ollama pull qwen2.5-coder:1.5b  # coding tasks (~900MB RAM)
ollama pull moondream            # vision/GUI (~800MB RAM)
```

---

## Running JARVIS

**Standard mode (terminal only):**
```bash
cd god-agent
python main.py
```

**With live dashboard:**
```bash
# Terminal 1:
ollama serve

# Terminal 2:
python dashboard.py
# → opens at http://localhost:5000

# Terminal 3:
python main.py
```

**Resume a session:**
```bash
python main.py --session <session-id>
```

---

## REPL Commands

| Command | What it does |
|---------|--------------|
| `exit` / `quit` | Shut down |
| `memory` | Show conversation history |
| `workspace` | List all saved agent artifacts |
| `recall <key>` | Read a specific workspace artifact |
| `session` | Show current session ID |
| `stop watching` | Cancel active proactive watch loop |

---

## Proactive Mode

JARVIS can watch for events autonomously — no polling the user.

From turn 2 onward, JARVIS decides if your input implies ongoing monitoring. If yes, it starts a background watch loop that:
- Reads the screen via Windows Accessibility API (zero LLM tokens)
- Polls a web URL/API on a smart interval (only wakes up when needed)
- Fires the full agent chain **only when the trigger condition is actually met**
- 5-minute cooldown after each trigger to prevent re-firing
- Stops when the stop condition is met or you type `stop watching`

**Example trigger inputs:**
- "Monitor train 12301 and alert me if it's delayed more than 20 minutes"
- "Watch my Gmail tab and tell me when anyone from @company.com emails me"
- "Keep an eye on Bitcoin price and notify me if it drops below $50,000"

---

## LLM Fallback Chain

```
Gemini (primary, largest free quota)
  → Groq (fast, generous free tier)
    → OpenRouter (optional, ~$0 with free models)
      → Ollama (local, completely free, unlimited, never runs out)
```

Ollama runs on your machine. On a 8GB RAM system, use models under 2B parameters (`qwen2.5:1.5b`). It's ~3-5 tokens/sec on CPU — slower than cloud but it **never fails mid-demo**.

---

## Shared Workspace

All substantial agent outputs are automatically saved to a shared SQLite workspace with descriptive keys. Any future agent call can reference prior work — no re-doing research that was already done.

```
You: Research the best free weather API
JARVIS: [research agent runs, finds open-meteo.com, saves spec to workspace]

You: Now build a weather dashboard for Hyderabad
JARVIS: [sees workspace has weather API spec, passes it directly to coding agent]
        [coding agent builds from real spec, not mock data]
```

---

## File Structure

```
god-agent/
├── main.py                    # JARVIS REPL entry point
├── dashboard.py               # Live web dashboard (http://localhost:5000)
├── requirements.txt
├── .env                       # API keys (fill this in)
│
├── god_agent/
│   ├── god_agent.py           # Orchestrator — routes, chains, retries
│   ├── prompts.py             # JARVIS self-awareness + routing prompts
│   └── proactivity.py        # Proactive watch loop engine
│
├── research_agent/
│   ├── agent.py               # Autonomous web research (3 modes)
│   ├── prompts.py             # research / scrape / api_scout prompts
│   └── search.py              # Serper + BeautifulSoup + DDG fallback
│
├── coding_agent/
│   ├── agent.py               # Autonomous coding + file management
│   ├── tools.py               # Full system-wide file/shell toolkit
│   ├── prompts.py             # Coding system prompt + plan prompt
│   └── workspace/             # Default coding workspace
│
├── app_agent/
│   └── agent.py               # Windows GUI automation wrapper
│
├── agent_cards/               # JSON capability cards (read by routing LLM)
│   ├── coding_agent.json
│   ├── research_agent.json
│   └── app_agent.json
│
├── schemas/
│   └── contract.py            # TaskRequest + AgentResponse (universal I/O)
│
├── memory/
│   └── memory.py              # Memory (conversation) + Workspace (artifacts)
│
├── utils/
│   ├── llm.py                 # Gemini → Groq → OpenRouter → Ollama fallback
│   ├── json_parser.py         # Robust JSON extraction from LLM output
│   └── logger.py              # Structured logging + task_log.jsonl
│
└── logs/
    ├── god_agent.log          # Full structured log
    └── task_log.jsonl         # Machine-readable task log (read by dashboard)
```

---

## Demo Script (for video submission)

**Setup (before recording):**
```bash
# Terminal 1: ollama serve
# Terminal 2: python dashboard.py
# Terminal 3: python main.py
# Browser: http://localhost:5000
```

**Demo sequence:**

1. **Simple task — DIRECT routing:**
   > "What is the difference between A* and Dijkstra's algorithm?"
   → JARVIS answers directly. Shows it's not just a router.

2. **Single agent — CODING:**
   > "Write and run a Python script that generates a Fibonacci sequence up to 1000"
   → Coding agent plans, writes, runs, shows output.

3. **Chain — RESEARCH → CODING (the money shot):**
   > "Find a free real-time weather API and build a working Python script that shows current weather for Hyderabad"
   → Research agent finds open-meteo.com (no auth), produces integration spec
   → Coding agent builds from real spec, runs it, shows live weather data

4. **Proactive mode:**
   > "Monitor the weather in Hyderabad and alert me if temperature goes above 40°C"
   → Watch loop starts, JARVIS goes proactive

5. **Workspace recall:**
   > Type: `workspace`
   → Shows all saved artifacts
   > "Use the weather API spec you found to also build a 5-day forecast script"
   → JARVIS sees workspace, routes coding agent directly to saved spec

6. **Mother OS pitch:**
   > "Now build a train delay monitoring script — research the best Indian Railways data source first"
   → Switches domains entirely. Same system, different project.

---

## Key Technical Differentiators

- **Zero hardcoded routing** — the LLM reads agent capability cards and reasons about task decomposition fresh every turn
- **True A2A context chaining** — research agent outputs structured API specs (not prose), coding agent builds from them
- **Proactive + reactive in one system** — user decides per-request, JARVIS decides per-turn after that
- **Self-aware orchestrator** — JARVIS knows its own architecture, workspace state, and agent capabilities
- **Infinite fallback** — Gemini → Groq → OpenRouter → Ollama. Demo never dies from credit exhaustion.
- **Shared persistent workspace** — artifacts survive across sessions; no re-doing prior research
