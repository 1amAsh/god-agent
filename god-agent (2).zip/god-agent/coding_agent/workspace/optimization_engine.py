# Optimization engine for Indian Rail API

from coding_agent.workspace.data_models import DelayInfo
from mock_data_fetcher import MockDataFetcher

class OptimizationEngine:
    def __init__(self, data_fetcher):
        self.data_fetcher = data_fetcher

    def optimize_schedules(self):
        delays = self.data_fetcher.get_delays()
        optimized_schedules = []
        for delay in delays:
            if delay.delay_minutes > 30:
                # Apply optimization rule: delay train by 30 minutes
                optimized_schedules.append({'train_id': delay.train.train_id, 'delay_minutes': delay.delay_minutes})
        return optimized_schedules