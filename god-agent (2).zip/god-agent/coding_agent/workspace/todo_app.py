import os

TODO_FILE = 'todos.txt'

def load_tasks():
    """Loads tasks from the TODO_FILE."""
    tasks = []
    if os.path.exists(TODO_FILE):
        with open(TODO_FILE, 'r') as f:
            for line in f:
                line = line.strip()
                if line:
                    status_char = line[0]
                    description = line[2:]
                    is_completed = (status_char == 'x')
                    tasks.append({'description': description, 'completed': is_completed})
    return tasks

def save_tasks(tasks):
    """Saves tasks to the TODO_FILE."""
    with open(TODO_FILE, 'w') as f:
        for task in tasks:
            status_char = 'x' if task['completed'] else ' '
            f.write(f"{status_char} {task['description']}\n")

def add_task(tasks, description):
    """Adds a new task to the list."""
    tasks.append({'description': description, 'completed': False})
    print(f"Task '{description}' added.")

def list_tasks(tasks):
    """Lists all tasks with their status and index."""
    if not tasks:
        print("No tasks found.")
        return
    print("\n--- Your Tasks ---")
    for i, task in enumerate(tasks):
        status = "[x]" if task['completed'] else "[ ]"
        print(f"{i + 1}. {status} {task['description']}")
    print("------------------\n")

def complete_task(tasks, task_index):
    """Marks a task as complete by its index."""
    try:
        index = int(task_index) - 1
        if 0 <= index < len(tasks):
            if not tasks[index]['completed']:
                tasks[index]['completed'] = True
                print(f"Task '{tasks[index]['description']}' marked as complete.")
            else:
                print(f"Task '{tasks[index]['description']}' is already complete.")
        else:
            print("Invalid task number.")
    except ValueError:
        print("Invalid input. Please enter a number.")

def delete_task(tasks, task_index):
    """Deletes a task by its index."""
    try:
        index = int(task_index) - 1
        if 0 <= index < len(tasks):
            deleted_task = tasks.pop(index)
            print(f"Task '{deleted_task['description']}' deleted.")
        else:
            print("Invalid task number.")
    except ValueError:
        print("Invalid input. Please enter a number.")

def main():
    tasks = load_tasks()

    while True:
        print("\n--- Todo App Menu ---")
        print("1. Add a new task")
        print("2. List all tasks")
        print("3. Mark task as complete")
        print("4. Delete a task")
        print("5. Exit")
        print("---------------------")

        choice = input("Enter your choice: ")

        if choice == '1':
            description = input("Enter task description: ")
            if description:
                add_task(tasks, description)
            else:
                print("Task description cannot be empty.")
        elif choice == '2':
            list_tasks(tasks)
        elif choice == '3':
            list_tasks(tasks) # Show tasks before asking for index
            task_num = input("Enter the number of the task to complete: ")
            complete_task(tasks, task_num)
        elif choice == '4':
            list_tasks(tasks) # Show tasks before asking for index
            task_num = input("Enter the number of the task to delete: ")
            delete_task(tasks, task_num)
        elif choice == '5':
            save_tasks(tasks)
            print("Exiting Todo App. Tasks saved.")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == '__main__':
    main()
