# Mock data fetcher for Indian Rail API

from coding_agent.workspace.data_models import Train, Station, ScheduleEntry, DelayInfo, WeatherInfo, TrackStatusInfo

class MockDataFetcher:
    def __init__(self):
        self.trains = [
            Train('12345', 'Shatabdi Express'),
            Train('67890', 'Rajdhani Express')
        ]
        self.stations = [
            Station('NDLS', 'New Delhi'),
            Station('BCT', 'Mumbai Central')
        ]
        self.schedules = [
            ScheduleEntry(self.trains[0], self.stations[0], '08:00', '09:00'),
            ScheduleEntry(self.trains[0], self.stations[1], '12:00', '13:00')
        ]
        self.delays = [
            DelayInfo(self.trains[0], 30)
        ]
        self.weather_info = [
            WeatherInfo(self.stations[0], 'Sunny')
        ]
        self.track_status_info = [
            TrackStatusInfo(self.stations[0], 'Clear')
        ]

    def get_schedules(self):
        return self.schedules

    def get_delays(self):
        return self.delays

    def get_weather_info(self):
        return self.weather_info

    def get_track_status_info(self):
        return self.track_status_info