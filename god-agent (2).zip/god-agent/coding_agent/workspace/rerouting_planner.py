# Rerouting planner for Indian Rail API

from coding_agent.workspace.data_models import TrackStatusInfo
from mock_data_fetcher import MockDataFetcher

class ReroutingPlanner:
    def __init__(self, data_fetcher):
        self.data_fetcher = data_fetcher

    def plan_rerouting(self):
        track_status_info = self.data_fetcher.get_track_status_info()
        rerouting_plan = []
        for track_status in track_status_info:
            if track_status.track_status == 'Blocked':
                # Apply rerouting rule: suggest alternative route
                rerouting_plan.append({'station_id': track_status.station.station_id, 'alternative_route': 'Route 2'})
        return rerouting_plan