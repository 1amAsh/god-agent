"""
dashboard.py — JARVIS live dashboard.

Run alongside main.py:
  Terminal 1: python dashboard.py
  Terminal 2: python main.py
  Browser:    http://localhost:5000

Shows real-time agent activity and shared workspace artifacts.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

BASE = Path(__file__).parent
sys.path.insert(0, str(BASE))
os.environ.setdefault("MEMORY_DB", str(BASE / "memory" / "jarvis.db"))

from flask import Flask, render_template_string, jsonify

app = Flask(__name__)

HTML = """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>JARVIS — God Agent</title>
<meta http-equiv="refresh" content="0">
<style>
  :root {
    --green: #00ff88; --dim: #00aa55; --bg: #080808;
    --card: #0d0d0d; --border: #1c1c1c;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    background: var(--bg); color: var(--green);
    font-family: 'Courier New', monospace; padding: 28px 32px;
  }
  .header { margin-bottom: 20px; }
  h1 { font-size: 30px; letter-spacing: 10px; color: #fff; }
  .sub { color: #2a2a2a; font-size: 11px; letter-spacing: 4px; margin-top: 4px; }
  .status-bar {
    display: flex; gap: 28px; margin: 16px 0 22px 0;
    font-size: 11px; color: #333; border-top: 1px solid #111;
    border-bottom: 1px solid #111; padding: 10px 0;
  }
  .pulse {
    display: inline-block; width: 7px; height: 7px; border-radius: 50%;
    background: var(--green); margin-right: 6px;
    animation: pulse 2s infinite;
  }
  @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.15} }
  .grid { display: grid; grid-template-columns: 1.4fr 1fr; gap: 16px; }
  .card {
    background: var(--card); border: 1px solid var(--border);
    border-radius: 3px; padding: 18px;
  }
  .card-title {
    font-size: 10px; letter-spacing: 4px; color: #2c2c2c;
    text-transform: uppercase; margin-bottom: 14px;
  }
  .log { height: 400px; overflow-y: auto; }
  .entry {
    border-bottom: 1px solid #0e0e0e; padding: 7px 0;
    font-size: 12px; line-height: 1.5;
  }
  .ts { color: #222; font-size: 10px; margin-right: 6px; }
  .badge {
    display: inline-block; padding: 1px 7px; border-radius: 2px;
    font-size: 10px; margin-right: 5px; font-weight: bold;
  }
  .coding   { background: #00112a; color: #3399ff; }
  .research { background: #1a1500; color: #ffcc00; }
  .app      { background: #1a0028; color: #cc44ff; }
  .god-agent{ background: #001a06; color: #00ff88; }
  .ok  { color: var(--green); margin-right: 4px; }
  .err { color: #ff3333; margin-right: 4px; }
  .task-text { color: #555; }
  .ws-item { padding: 9px 0; border-bottom: 1px solid #0e0e0e; }
  .ws-key { color: #00cc66; font-size: 12px; }
  .ws-meta { color: #2a2a2a; font-size: 10px; margin-top: 3px; }
  .empty { color: #1e1e1e; font-size: 12px; padding: 20px 0; }
  .stat { color: var(--green); }
</style>
<script>
  async function refresh() {
    try {
      const [logRes, wsRes] = await Promise.all([
        fetch('/api/log'), fetch('/api/workspace')
      ]);
      const log = await logRes.json();
      const ws  = await wsRes.json();

      const logEl = document.getElementById('log');
      if (log.entries.length === 0) {
        logEl.innerHTML = '<div class="empty">No agent activity yet. Start main.py and give JARVIS a task.</div>';
      } else {
        logEl.innerHTML = log.entries.map(e => `
          <div class="entry">
            <span class="ts">${e.ts ? e.ts.slice(11,19) : ''}</span>
            <span class="badge ${e.agent || ''}">${e.agent || '?'}</span>
            <span class="${e.success ? 'ok' : 'err'}">${e.success ? '✓' : '✗'}</span>
            <span class="task-text">${(e.task || '').slice(0, 90)}</span>
          </div>`).join('');
        logEl.scrollTop = logEl.scrollHeight;
      }

      const wsEl = document.getElementById('workspace');
      if (ws.items.length === 0) {
        wsEl.innerHTML = '<div class="empty">No artifacts yet. Complete a research or coding task.</div>';
      } else {
        wsEl.innerHTML = ws.items.map(i => `
          <div class="ws-item">
            <div class="ws-key">${i.key}</div>
            <div class="ws-meta">
              ${i.agent} &nbsp;·&nbsp; ${i.ts ? i.ts.slice(0,16) : ''} &nbsp;·&nbsp; ${i.size} chars
            </div>
          </div>`).join('');
      }

      document.getElementById('ev-count').textContent = log.entries.length;
      document.getElementById('ws-count').textContent = ws.items.length;
    } catch(e) {
      console.warn('refresh error', e);
    }
  }
  setInterval(refresh, 2000);
  refresh();
</script>
</head>
<body>
  <div class="header">
    <h1>⚡ JARVIS</h1>
    <div class="sub">GOD AGENT &nbsp;·&nbsp; MULTI-AGENT AI OPERATING SYSTEM</div>
  </div>
  <div class="status-bar">
    <span><span class="pulse"></span>LIVE</span>
    <span><span class="stat" id="ev-count">—</span> events</span>
    <span><span class="stat" id="ws-count">—</span> workspace artifacts</span>
    <span style="margin-left:auto">localhost:5000</span>
  </div>
  <div class="grid">
    <div class="card">
      <div class="card-title">Agent Activity Log</div>
      <div class="log" id="log">Loading...</div>
    </div>
    <div class="card">
      <div class="card-title">Shared Workspace</div>
      <div class="log" id="workspace">Loading...</div>
    </div>
  </div>
</body>
</html>"""


@app.route('/')
def index():
    return render_template_string(HTML)


@app.route('/api/log')
def api_log():
    log_path = BASE / "logs" / "task_log.jsonl"
    entries = []
    if log_path.exists():
        try:
            lines = log_path.read_text(encoding="utf-8").strip().split('\n')
            for line in lines[-60:]:
                if line.strip():
                    try:
                        entries.append(json.loads(line))
                    except Exception:
                        pass
        except Exception:
            pass
    return jsonify({"entries": entries})


@app.route('/api/workspace')
def api_workspace():
    try:
        from memory.memory import Workspace
        ws = Workspace()
        return jsonify({"items": ws.list_keys()})
    except Exception as e:
        return jsonify({"items": [], "error": str(e)})


if __name__ == '__main__':
    print("JARVIS Dashboard running at http://localhost:5000")
    print("Keep this running alongside main.py")
    app.run(port=5000, debug=False, use_reloader=False)
