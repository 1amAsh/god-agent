"""
memory/memory.py — Conversation memory + shared agent workspace, backed by SQLite.

Two stores:
  1. messages   — per-session conversation history
  2. workspace  — named artifacts any agent can write/read across sessions
                  Agents decide when to use this via their prompts — nothing hardcoded.
"""
from __future__ import annotations

import os
import sqlite3
from datetime import datetime
from pathlib import Path

DB_PATH = Path(os.environ.get("MEMORY_DB", "memory/jarvis.db"))


def _conn() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(DB_PATH))
    con.execute("""
        CREATE TABLE IF NOT EXISTS messages (
            id       INTEGER PRIMARY KEY AUTOINCREMENT,
            session  TEXT NOT NULL,
            role     TEXT NOT NULL,
            content  TEXT NOT NULL,
            ts       TEXT NOT NULL
        )
    """)
    con.execute("""
        CREATE TABLE IF NOT EXISTS workspace (
            id       INTEGER PRIMARY KEY AUTOINCREMENT,
            key      TEXT NOT NULL UNIQUE,
            content  TEXT NOT NULL,
            agent    TEXT NOT NULL,
            session  TEXT NOT NULL,
            ts       TEXT NOT NULL
        )
    """)
    con.commit()
    return con


class Memory:
    """Session-scoped conversation memory."""

    def save(self, session: str, role: str, content: str) -> None:
        with _conn() as con:
            con.execute(
                "INSERT INTO messages (session, role, content, ts) VALUES (?, ?, ?, ?)",
                (session, role, content, datetime.utcnow().isoformat()),
            )

    def recent(self, session: str, limit: int = 10) -> list[dict]:
        with _conn() as con:
            rows = con.execute(
                "SELECT role, content FROM messages WHERE session=? ORDER BY id DESC LIMIT ?",
                (session, limit),
            ).fetchall()
        return [{"role": r, "content": c} for r, c in reversed(rows)]

    def context_text(self, session: str, limit: int = 8) -> str:
        msgs = self.recent(session, limit)
        if not msgs:
            return "(no prior conversation)"
        lines = []
        for m in msgs:
            tag = "USER" if m["role"] == "user" else "JARVIS"
            lines.append(f"{tag}: {m['content'][:600]}")
        return "\n".join(lines)

    def clear(self, session: str) -> None:
        with _conn() as con:
            con.execute("DELETE FROM messages WHERE session=?", (session,))


class Workspace:
    """
    Shared artifact store — any agent can write/read named artifacts across sessions.

    Keys are human-readable descriptive names like:
      "railway_api_spec", "train_delay_report", "weather_dashboard_src"

    Agents decide when to use this because their prompts tell them it exists
    and what it's for. Nothing in the orchestrator hardcodes save/load calls.
    """

    def write(self, key: str, content: str, agent: str, session: str) -> None:
        with _conn() as con:
            con.execute("""
                INSERT INTO workspace (key, content, agent, session, ts)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(key) DO UPDATE SET
                    content=excluded.content,
                    agent=excluded.agent,
                    session=excluded.session,
                    ts=excluded.ts
            """, (key, content, agent, session, datetime.utcnow().isoformat()))

    def read(self, key: str) -> str | None:
        with _conn() as con:
            row = con.execute(
                "SELECT content FROM workspace WHERE key=?", (key,)
            ).fetchone()
        return row[0] if row else None

    def list_keys(self) -> list[dict]:
        with _conn() as con:
            rows = con.execute(
                "SELECT key, agent, session, ts, length(content) as size "
                "FROM workspace ORDER BY ts DESC"
            ).fetchall()
        return [{"key": r[0], "agent": r[1], "session": r[2], "ts": r[3], "size": r[4]} for r in rows]

    def delete(self, key: str) -> None:
        with _conn() as con:
            con.execute("DELETE FROM workspace WHERE key=?", (key,))

    def snapshot(self) -> str:
        """Compact summary of workspace contents — injected into every routing call."""
        items = self.list_keys()
        if not items:
            return "(workspace is empty)"
        lines = [
            f"  [{i['key']}] by {i['agent']} at {i['ts'][:16]} ({i['size']} chars)"
            for i in items
        ]
        return "\n".join(lines)
