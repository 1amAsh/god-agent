"""
app_agent/agent.py — App Agent wrapper conforming to the God Agent I/O contract.

The core logic lives in individual-agents/app_agent/agent.py (AppAgent class).
This wrapper:
  1. Accepts TaskRequest and returns AgentResponse.
  2. Injects prior context into the task description.
  3. Adapts the raw AppAgent result to the unified contract.
  4. Provides a standalone fallback if the individual agent isn't importable.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path
from typing import Optional

# Allow importing from individual-agents
_INDIVIDUAL = Path(__file__).parent.parent.parent / "individual-agents" / "app_agent"
sys.path.insert(0, str(_INDIVIDUAL))
sys.path.insert(0, str(Path(__file__).parent.parent))

from dotenv import find_dotenv, load_dotenv
load_dotenv(find_dotenv())

from schemas.contract import TaskRequest, AgentResponse
from utils.logger import logger, record_task


class AppAgent:
    """
    Wrapper around the individual App Agent.
    Conforms to God Agent I/O contract: run(TaskRequest) → AgentResponse
    """

    def __init__(self) -> None:
        self._core: Optional[object] = None
        self._available = False
        try:
            from agent import AppAgent as _CoreAppAgent  # type: ignore
            self._core = _CoreAppAgent()
            self._available = True
            logger.info("[app-agent] Core agent loaded successfully.")
        except ImportError as e:
            logger.warning(f"[app-agent] Core agent not importable (Windows only?): {e}")

    def run(self, request: TaskRequest) -> AgentResponse:
        task = request.task
        context = request.context or ""
        start = time.time()

        if not self._available or self._core is None:
            return AgentResponse(
                status="fail",
                result="",
                agent="app",
                error=(
                    "App Agent is not available in this environment. "
                    "It requires Windows with pywinauto installed. "
                    "Run the app_agent from individual-agents/app_agent directly."
                ),
            )

        # Terminal safety — injected at wrapper level, prevents Ctrl+C self-kill
        TERMINAL_SAFETY = (
            "TERMINAL SAFETY RULES (ABSOLUTE, NON-NEGOTIABLE):\n"
            "- NEVER send Ctrl+C, Ctrl+Z, Ctrl+D, Ctrl+Break to ANY terminal window.\n"
            "- NEVER interact with Windows Terminal, PowerShell, CMD, or any Python terminal.\n"
            "- The terminal running JARVIS is OFF LIMITS. Do not focus it. Do not send keys to it.\n"
            "- To read terminal output: use READ_TREE or GET_TEXT — never send keyboard shortcuts.\n"
            "- If only a terminal window is open: report no GUI target available, do not interact.\n"
            "- Code execution goes to the CODING AGENT, not you.\n\n"
        )

        # Inject context into task if present
        full_task = TERMINAL_SAFETY + task
        if context:
            full_task = (
                TERMINAL_SAFETY +
                f"CONTEXT FROM PRIOR STEPS:\n{context[:1000]}\n\n"
                f"YOUR TASK: {task}"
            )

        logger.info(f"[app-agent] Task: {task!r}")

        try:
            raw_result = self._core.run(full_task)  # type: ignore
            duration = time.time() - start

            # Determine success heuristically
            failed = (
                raw_result.startswith("[ABORTED]") or
                raw_result.startswith("[Task incomplete") or
                raw_result.startswith("[Agent error") or
                raw_result.startswith("[LLM error")
            )

            record_task(
                session_id="app",
                task=task[:300],
                agent="app",
                result=raw_result[:500],
                success=not failed,
                duration_s=duration,
            )

            return AgentResponse(
                status="fail" if failed else "success",
                result=raw_result,
                next_hint="GUI task completed. The desktop state has been modified.",
                agent="app",
                error=raw_result if failed else "",
            )

        except Exception as exc:
            duration = time.time() - start
            error_msg = f"App agent raised an exception: {exc}"
            logger.error(f"[app-agent] {error_msg}")
            record_task("app", task[:300], "app", error_msg, False, duration)
            return AgentResponse(
                status="fail",
                result="",
                agent="app",
                error=error_msg,
            )
