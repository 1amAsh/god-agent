# JARVIS — God Agent

A multi-agent AI operating system. One natural language input. Three specialized agents. Pure LLM orchestration — no hardcoded routing.

```
You: Research Tesla's competitors, then build a comparison dashboard app
JARVIS: [routes to research → coding, passes research output as context]
        [builds a working Python dashboard with real competitor data]
```

---

## File Structure

```
god-agent/
├── individual-agents/          ← Original agents — untouched, reference only
│   ├── app_agent/
│   ├── coding-agent/
│   └── research-agent/
│
└── god-agent/                  ← The new combined system (this folder)
    ├── main.py                 ← Entry point — run this
    ├── .env                    ← All API keys go here
    ├── requirements.txt
    │
    ├── god_agent/
    │   ├── god_agent.py        ← Central orchestration brain
    │   └── prompts.py          ← JARVIS routing + formatting prompts
    │
    ├── coding_agent/
    │   ├── agent.py            ← Coding + file management agent
    │   ├── tools.py            ← System-wide file ops + shell
    │   ├── prompts.py          ← Coding agent system prompts
    │   └── workspace/          ← Default working directory
    │
    ├── research_agent/
    │   ├── agent.py            ← Web research + scraping agent
    │   ├── search.py           ← Serper/Google + DDG + BeautifulSoup fetcher
    │   └── prompts.py          ← Research + scrape mode prompts
    │
    ├── app_agent/
    │   └── agent.py            ← Windows GUI automation wrapper
    │
    ├── agent_cards/            ← Agent capability descriptions (JSON)
    │   ├── coding_agent.json
    │   ├── research_agent.json
    │   └── app_agent.json
    │
    ├── schemas/
    │   └── contract.py         ← Universal I/O contract (TaskRequest / AgentResponse)
    │
    ├── memory/
    │   └── memory.py           ← SQLite conversation memory
    │
    ├── utils/
    │   ├── llm.py              ← Unified LLM client (Groq / Gemini / DeepSeek)
    │   ├── json_parser.py      ← Robust JSON extraction from LLM output
    │   └── logger.py           ← Structured logging
    │
    └── logs/                   ← Auto-created at runtime
```

---

## Setup

```bash
cd god-agent/god-agent

# Install dependencies
pip install -r requirements.txt

# Edit .env with your API keys (already pre-filled with your keys)
# Minimum required: GROQ_API_KEY or GEMINI_API_KEY
```

---

## Running

```bash
# Interactive REPL
python main.py

# Single command
python main.py "build a todo app in Python"
python main.py "research the latest news on OpenAI"
python main.py "open Chrome and go to youtube.com"

# Resume a previous session
python main.py --session abc12345
```

---

## The I/O Contract

Every agent follows the same interface — they're completely interchangeable from the God Agent's perspective.

**In:**
```python
@dataclass
class TaskRequest:
    task: str          # natural language task
    context: str       # prior agent output (for chaining)
    metadata: dict     # agent-specific hints
```

**Out:**
```python
@dataclass
class AgentResponse:
    status: str        # "success" | "fail" | "partial"
    result: str        # the output
    next_hint: str     # optional hint for the next agent
    agent: str         # which agent produced this
    error: str         # populated on failure
```

---

## Task Types

The God Agent's LLM decides which type applies — no keyword matching:

| Type | Description | Example |
|------|-------------|---------|
| `DIRECT` | Answered by JARVIS itself | "What is 2+2?" |
| `SINGLE` | One agent handles it | "Build a calculator app" |
| `CHAIN` | Sequential: output of agent N feeds into agent N+1 | "Research Python frameworks, then build one" |
| `PARALLEL` | Independent tasks run concurrently | "Open Spotify AND search for its discography" |

---

## Agent Capabilities

### Coding Agent
- Writes complete multi-file projects in any language
- **System-wide file management**: move, rename, copy, delete files/folders anywhere on disk (not just workspace)
- Runs shell commands, installs dependencies, verifies output
- FIND_FILE: recursive system-wide file search

### Research Agent
- Google search via Serper API (falls back to DuckDuckGo)
- Full page content fetching with BeautifulSoup HTML cleaning
- Two modes: `research` (deep multi-source) and `scrape` (targeted extraction)
- Includes answer boxes, knowledge graphs from search results

### App Agent *(Windows only)*
- Opens any Windows application
- Accessibility tree reading (UIA) — no coordinate guessing
- Screenshot + vision fallback for web content
- Hotkeys, menu navigation, typing into fields

---

## Chaining Example

```
You: Research the top Python web frameworks and their GitHub stars, 
     then build a bar chart app comparing them

God Agent:
  Step 1 → research agent: searches and fetches framework data
  Step 2 → coding agent: receives research output as context,
            builds a matplotlib bar chart with real data
```

The coding agent's context will contain the research results — it builds the chart with actual numbers, not placeholders.

---

## Adding a New Agent

1. Create `your_agent/agent.py` with a class that has `run(TaskRequest) → AgentResponse`
2. Add `agent_cards/your_agent.json` with `agent_id`, `description`, and `capabilities`
3. Add a case to `_get_agent()` in `god_agent/god_agent.py`

The routing LLM will automatically learn what the new agent can do from its card.

---

## LLM Provider Fallback

```
Primary: GOD_LLM_PROVIDER (default: gemini)
    ↓ daily limit?
Secondary: groq
    ↓ daily limit?
Tertiary: deepseek
```

All three providers are pre-configured in `.env`.
