"""
god_agent/proactivity.py — Proactive watch engine.

After every user input the LLM decides:
  - reactive  : handle once, done
  - proactive : keep watching a condition, fire agent chain when triggered

When proactive:
  - Reads screen via Windows Accessibility API first (zero LLM tokens)
  - Only takes a screenshot if the tree returns nothing useful
  - Sleeps intelligently between checks (if next check is in 10 mins, sleeps 10 mins)
  - Fires the full God Agent only when the trigger condition is actually met
  - Stops when stop condition is met or user hits Ctrl+C
"""
from __future__ import annotations

import time
import threading
from dataclasses import dataclass, field
from typing import Optional, Callable

from utils.llm import call_llm
from utils.json_parser import extract_json
from utils.logger import logger

# ── Token-lean decider prompt ─────────────────────────────────────────
# Intentionally short. This runs on EVERY user input so we keep it minimal.

DECIDER_PROMPT = """\
You decide if a user request is reactive (answer once) or proactive (keep watching).

Reactive: questions, build tasks, research, one-shot commands.
Proactive: monitoring, watching for events, waiting for something to happen, standing by.

Examples of proactive triggers:
- "monitor train 12345 and alert me if it's delayed more than 20 mins"
- "watch my inbox and tell me when X emails me"
- "keep an eye on this stock and notify me if it drops below Y"
- "stand by and alert me if [anything changes on screen]"
- "watch the railway dashboard and tell me when platform changes happen"

For proactive, also decide HOW to check: accessibility_tree | web_poll | both
- accessibility_tree: reading a visible app/browser window on screen
- web_poll: hitting a URL or API endpoint periodically
- both: check tree first, fall back to web if tree is empty

Respond ONLY with this JSON, nothing else:
{
  "mode": "reactive | proactive",
  "trigger_condition": "exact condition that should fire the agent — be specific",
  "check_interval_seconds": 60,
  "stop_condition": "when to stop watching entirely",
  "check_method": "accessibility_tree | web_poll | both",
  "poll_target": "URL or search query if web_poll, else null",
  "reasoning": "one line"
}

If reactive, set mode=reactive and leave everything else null/0.\
"""

# ── Token-lean screen reader prompt ──────────────────────────────────
# This runs every check cycle. Must be as short as possible.

SCREEN_EVAL_PROMPT = """\
You are a lightweight trigger evaluator. Given screen text and a trigger condition, decide if the condition is met.

Trigger condition: {condition}
Stop condition: {stop}

Screen text (trimmed):
{screen_text}

Respond ONLY with JSON:
{{"triggered": true/false, "stop": true/false, "reason": "one line max"}}
No other text.\
"""


@dataclass
class WatchConfig:
    trigger_condition: str
    check_interval_seconds: int
    stop_condition: str
    check_method: str           # accessibility_tree | web_poll | both
    poll_target: Optional[str]  # URL or search query for web_poll


class ProactivityDecider:
    """
    Single LLM call per user input.
    Returns (mode, WatchConfig|None).
    """

    def decide(self, user_input: str) -> tuple[str, Optional[WatchConfig]]:
        raw = call_llm(
            DECIDER_PROMPT,
            [{"role": "user", "content": user_input}],
            max_tokens=256,   # intentionally tiny — this is a classifier
        )
        parsed = extract_json(raw)
        if not parsed or parsed.get("mode") == "reactive":
            return "reactive", None

        cfg = WatchConfig(
            trigger_condition=parsed.get("trigger_condition", user_input),
            check_interval_seconds=max(10, int(parsed.get("check_interval_seconds") or 60)),
            stop_condition=parsed.get("stop_condition", "user says stop"),
            check_method=parsed.get("check_method", "both"),
            poll_target=parsed.get("poll_target"),
        )
        logger.info(
            f"[proactive] mode=proactive | interval={cfg.check_interval_seconds}s "
            f"| method={cfg.check_method} | trigger={cfg.trigger_condition!r}"
        )
        return "proactive", cfg


class ScreenReader:
    """
    Reads screen state with minimal token cost.
    Priority: accessibility tree → web poll → skip screenshot entirely unless forced.
    """

    def read(self, cfg: WatchConfig) -> str:
        parts = []

        if cfg.check_method in ("accessibility_tree", "both"):
            tree_text = self._read_accessibility_tree()
            if tree_text:
                parts.append(f"[SCREEN]\n{tree_text[:3000]}")

        if cfg.check_method in ("web_poll", "both") and cfg.poll_target:
            web_text = self._poll_web(cfg.poll_target)
            if web_text:
                parts.append(f"[WEB]\n{web_text[:3000]}")

        if not parts:
            # Absolutely nothing — don't take a screenshot, just return empty
            return ""

        return "\n\n".join(parts)

    def _read_accessibility_tree(self) -> str:
        """
        Read foreground window text via Windows UIA.
        Returns plain text — zero LLM tokens.
        Skips silently on non-Windows.
        """
        try:
            import pywinauto
            from pywinauto import Desktop

            desktop = Desktop(backend="uia")
            # Get the foreground window
            try:
                import ctypes
                hwnd = ctypes.windll.user32.GetForegroundWindow()
                windows = desktop.windows()
                target = None
                for w in windows:
                    try:
                        if w.handle == hwnd:
                            target = w
                            break
                    except Exception:
                        continue
                if not target:
                    target = windows[0] if windows else None
            except Exception:
                target = None

            if not target:
                return ""

            # Walk the tree cheaply — collect visible text
            texts = []
            try:
                wrapper = target.wrapper_object()
                self._collect_text(wrapper, texts, depth=0, max_depth=4)
            except Exception:
                try:
                    texts = [target.window_text()]
                except Exception:
                    pass

            return "\n".join(t for t in texts if t.strip())[:4000]

        except ImportError:
            return ""
        except Exception as e:
            logger.debug(f"[screen-reader] accessibility error: {e}")
            return ""

    def _collect_text(self, element, out: list, depth: int, max_depth: int) -> None:
        if depth > max_depth:
            return
        try:
            text = element.window_text()
            if text and text.strip():
                out.append(text.strip())
        except Exception:
            pass
        try:
            for child in element.children():
                self._collect_text(child, out, depth + 1, max_depth)
        except Exception:
            pass

    def _poll_web(self, target: str) -> str:
        """
        Fetch a URL or run a search query.
        For railway monitoring: target is the NTES/train status URL.
        For email: target is a gmail/outlook web URL (accessibility tree is better).
        """
        try:
            # If it looks like a URL, fetch it
            if target.startswith("http"):
                from research_agent.search import fetch_page
                return fetch_page(target, max_chars=4000)
            else:
                # Treat as a search query — get top snippet only, don't fetch full page
                from research_agent.search import web_search
                results = web_search(target, max_results=3)
                if results:
                    return "\n".join(
                        f"{r['title']}: {r['snippet']}" for r in results
                    )
        except Exception as e:
            logger.debug(f"[screen-reader] web poll error: {e}")
        return ""


class TriggerEvaluator:
    """
    Token-lean check: does the screen text meet the trigger condition?
    Uses the smallest possible LLM call.
    """

    def check(self, screen_text: str, cfg: WatchConfig) -> tuple[bool, bool]:
        """
        Returns (triggered, should_stop).
        If screen_text is empty, returns (False, False) without any LLM call.
        """
        if not screen_text.strip():
            return False, False

        prompt = SCREEN_EVAL_PROMPT.format(
            condition=cfg.trigger_condition,
            stop=cfg.stop_condition,
            screen_text=screen_text[:2000],  # hard trim before sending
        )

        raw = call_llm(
            "You are a trigger evaluator. Respond only with JSON.",
            [{"role": "user", "content": prompt}],
            max_tokens=64,   # absolute minimum — just need true/false
        )
        parsed = extract_json(raw)
        if not parsed:
            return False, False

        return bool(parsed.get("triggered")), bool(parsed.get("stop"))


class WatchLoop:
    """
    Runs the proactive monitoring loop in a background thread.

    - Reads screen on each cycle
    - Evaluates trigger with minimal LLM call
    - Fires full God Agent only when triggered
    - Sleeps intelligently between checks
    - Stops on stop condition or external cancel()
    """

    def __init__(self, cfg: WatchConfig, on_trigger: Callable[[str], str]):
        self.cfg = cfg
        self.on_trigger = on_trigger   # callback — fires the God Agent
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._reader = ScreenReader()
        self._evaluator = TriggerEvaluator()

    def start(self) -> None:
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        logger.info(f"[watch-loop] Started. Interval={self.cfg.check_interval_seconds}s")
        print(
            f"\n[JARVIS] Now watching: {self.cfg.trigger_condition}\n"
            f"         Checking every {self.cfg.check_interval_seconds}s. "
            f"Type 'stop watching' to cancel.\n"
        )

    def cancel(self) -> None:
        self._stop_event.set()
        logger.info("[watch-loop] Cancelled.")

    def is_running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def _loop(self) -> None:
        while not self._stop_event.is_set():
            try:
                screen_text = self._reader.read(self.cfg)
                triggered, should_stop = self._evaluator.check(screen_text, self.cfg)

                if triggered:
                    logger.info("[watch-loop] Trigger condition met — firing agent chain")
                    print(f"\n[JARVIS] ⚡ Trigger detected: {self.cfg.trigger_condition}")
                    # Build a concise task description — don't re-explain everything
                    task = (
                        f"PROACTIVE TRIGGER: {self.cfg.trigger_condition}\n\n"
                        f"CURRENT STATE:\n{screen_text[:2000]}"
                    )
                    result = self.on_trigger(task)
                    print(f"\n[JARVIS] {result}\n")

                if should_stop:
                    logger.info("[watch-loop] Stop condition met — ending watch.")
                    print(f"\n[JARVIS] Stop condition met. No longer watching.\n")
                    break

            except Exception as e:
                logger.error(f"[watch-loop] Error in cycle: {e}")

            # Smart sleep — break into 2s chunks so cancel() is responsive
            interval = self.cfg.check_interval_seconds
            slept = 0
            while slept < interval and not self._stop_event.is_set():
                time.sleep(min(2, interval - slept))
                slept += 2