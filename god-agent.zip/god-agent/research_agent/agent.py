"""
research_agent/agent.py — Autonomous research and scraping agent.

Improvements over original:
  - Accepts TaskRequest / returns AgentResponse (God Agent I/O contract).
  - Injects prior-agent context into research task.
  - Mode auto-detection: defaults to research, switches to scrape when task implies it.
  - Retry logic for parse failures.
  - Uses improved search.py (BeautifulSoup, Serper answer boxes, DDG fallback).
"""
from __future__ import annotations

import os
import sys
import time
from pathlib import Path
from typing import Optional

sys.path.insert(0, str(Path(__file__).parent.parent))

from dotenv import find_dotenv, load_dotenv
load_dotenv(find_dotenv())

from research_agent.search import web_search, fetch_page
from research_agent.prompts import RESEARCH_PROMPT, SCRAPE_PROMPT
from schemas.contract import TaskRequest, AgentResponse
from utils.llm import call_llm
from utils.json_parser import extract_json
from utils.logger import logger, record_task

MAX_STEPS = 40
RESULT_TRIM = 12_000
CONTEXT_TRIM = 5_000

# Keywords that suggest scraping over research
_SCRAPE_HINTS = {
    "scrape", "extract", "get all", "list all", "download data",
    "parse", "crawl", "fetch prices", "get prices", "get table",
}


def _detect_mode(task: str, metadata: dict) -> str:
    if metadata.get("mode"):
        return metadata["mode"]
    lowered = task.lower()
    if any(h in lowered for h in _SCRAPE_HINTS):
        return "scrape"
    return "research"


def _execute(action: dict) -> str:
    atype = action.get("type", "").upper()

    if atype == "SEARCH":
        query = action.get("query", "").strip()
        if not query:
            return "[SEARCH error: empty query]"
        max_r = min(int(action.get("max_results", 10)), 10)
        results = web_search(query, max_r)
        if not results:
            # Widen and retry once
            for suffix in [" overview", " wikipedia", " explained"]:
                results = web_search(query + suffix, max_r)
                if results:
                    break
            if not results:
                return f"[SEARCH error: no results for {query!r}]"
        lines = []
        for i, r in enumerate(results, 1):
            lines.append(
                f"{i}. **{r['title']}**\n"
                f"   URL: {r['url']}\n"
                f"   {r['snippet']}"
            )
        return "\n\n".join(lines)

    if atype == "FETCH_PAGE":
        url = action.get("url", "").strip()
        if not url:
            return "[FETCH_PAGE error: no URL provided]"
        return fetch_page(url, max_chars=RESULT_TRIM)

    if atype == "FINISH":
        return action.get("output", "")

    return f"[ERROR] Unknown action: {atype!r}"


class ResearchAgent:
    """
    Autonomous web research and scraping agent.

    Conforms to the God Agent I/O contract:
        run(request: TaskRequest) → AgentResponse
    """

    def run(self, request: TaskRequest) -> AgentResponse:
        task = request.task
        context = request.context or ""
        mode = _detect_mode(task, request.metadata)

        logger.info(f"[research-agent] Mode={mode} Task={task!r}")
        start = time.time()

        system_prompt = RESEARCH_PROMPT if mode == "research" else SCRAPE_PROMPT
        context_prefix = f"PRIOR CONTEXT (from earlier agents):\n{context[:1500]}\n\n" if context else ""

        messages: list[dict] = [
            {
                "role": "user",
                "content": (
                    f"{context_prefix}"
                    f"TASK: {task}\n\n"
                    f"Begin your {mode}."
                ),
            }
        ]
        history: list[dict] = []
        final_output = f"[{mode} incomplete — reached {MAX_STEPS} step limit]"
        parse_failures = 0

        for step in range(1, MAX_STEPS + 1):
            print(f"[research step {step:02d}] Thinking...", end=" ", flush=True)

            try:
                raw = call_llm(system_prompt, messages)
            except Exception as exc:
                final_output = f"[LLM error at step {step}: {exc}]"
                break

            parsed = extract_json(raw)
            if not parsed:
                parse_failures += 1
                print(f"parse-error ({parse_failures}/3)")
                if parse_failures >= 3:
                    final_output = "[Agent error: 3 consecutive JSON parse failures]"
                    break
                messages.append({"role": "assistant", "content": raw})
                messages.append({
                    "role": "user",
                    "content": "Your response was not valid JSON. Respond with ONLY a single valid JSON object.",
                })
                continue

            parse_failures = 0
            thought = parsed.get("thought", "")
            action = parsed.get("action", {})
            done = parsed.get("done", False)
            atype = action.get("type", "?").upper()

            print(atype)
            if thought:
                print(f"         → {thought.splitlines()[0][:120]}")

            if atype == "FINISH" or done:
                final_output = action.get("output", thought)
                history.append({"thought": thought, "action": action, "result": "DONE"})
                print(f"\n[research-agent] ✓ COMPLETE")
                break

            result = _execute(action)
            result_ctx = result if len(result) <= CONTEXT_TRIM else result[:CONTEXT_TRIM] + "\n[… truncated]"
            print(f"         ← {result_ctx.splitlines()[0][:100]}")

            history.append({"thought": thought, "action": action, "result": result[:2000]})
            messages.append({"role": "assistant", "content": raw})
            messages.append({"role": "user", "content": f"RESULT:\n{result_ctx}"})

        duration = time.time() - start
        success = not final_output.startswith("[") or "DONE" in final_output

        record_task(
            session_id="research",
            task=task[:300],
            agent="research",
            result=final_output[:500],
            success=success,
            duration_s=duration,
        )

        return AgentResponse(
            status="success" if success else "fail",
            result=final_output,
            next_hint="Research output can be passed as context to the coding agent to build something around this data.",
            agent="research",
            error="" if success else final_output,
        )
