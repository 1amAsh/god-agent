"""
memory/memory.py — Conversation memory backed by SQLite.

Stores per-session message history so the God Agent has context
across turns without bloating the LLM context window.
"""
from __future__ import annotations

import json
import os
import sqlite3
from datetime import datetime
from pathlib import Path


DB_PATH = Path(os.environ.get("MEMORY_DB", "memory/jarvis.db"))


def _conn() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(DB_PATH))
    con.execute("""
        CREATE TABLE IF NOT EXISTS messages (
            id       INTEGER PRIMARY KEY AUTOINCREMENT,
            session  TEXT NOT NULL,
            role     TEXT NOT NULL,
            content  TEXT NOT NULL,
            ts       TEXT NOT NULL
        )
    """)
    con.commit()
    return con


class Memory:
    """Simple session-scoped conversation memory."""

    def save(self, session: str, role: str, content: str) -> None:
        with _conn() as con:
            con.execute(
                "INSERT INTO messages (session, role, content, ts) VALUES (?, ?, ?, ?)",
                (session, role, content, datetime.utcnow().isoformat()),
            )

    def recent(self, session: str, limit: int = 10) -> list[dict]:
        """Return last `limit` messages as [{role, content}, ...]."""
        with _conn() as con:
            rows = con.execute(
                "SELECT role, content FROM messages WHERE session=? ORDER BY id DESC LIMIT ?",
                (session, limit),
            ).fetchall()
        return [{"role": r, "content": c} for r, c in reversed(rows)]

    def context_text(self, session: str, limit: int = 8) -> str:
        """Return recent history as readable text for prompt injection."""
        msgs = self.recent(session, limit)
        if not msgs:
            return "(no prior conversation)"
        lines = []
        for m in msgs:
            tag = "USER" if m["role"] == "user" else "JARVIS"
            lines.append(f"{tag}: {m['content'][:600]}")
        return "\n".join(lines)

    def clear(self, session: str) -> None:
        with _conn() as con:
            con.execute("DELETE FROM messages WHERE session=?", (session,))
