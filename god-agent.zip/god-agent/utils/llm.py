"""
utils/llm.py — Unified LLM client for the God Agent system.

Supports Groq, Gemini, and DeepSeek with automatic failover.
All providers present the same interface: call_llm(system, messages) → str
"""
from __future__ import annotations

import os
import time
from typing import Optional

# ── Model registries ──────────────────────────────────────────────────

GROQ_MODELS: dict[str, str] = {
    "llama":   "llama-3.3-70b-versatile",
    "llama3":  "llama-3.3-70b-versatile",
    "mixtral": "mixtral-8x7b-32768",
    "gemma":   "gemma2-9b-it",
    "fast":    "gemma2-9b-it",
    "long":    "mixtral-8x7b-32768",
    "best":    "llama-3.3-70b-versatile",
    "default": "llama-3.3-70b-versatile",
}
DEFAULT_GROQ_MODEL = "llama-3.3-70b-versatile"


def _resolve_groq(hint: Optional[str]) -> str:
    if not hint:
        return os.environ.get("GROQ_MODEL", DEFAULT_GROQ_MODEL)
    return GROQ_MODELS.get(hint.lower().strip(), hint)


# ── Provider implementations ──────────────────────────────────────────

def _call_groq(system: str, messages: list[dict], model: str, max_tokens: int) -> str:
    from groq import Groq
    api_key = os.environ.get("GROQ_API_KEY", "")
    if not api_key:
        raise RuntimeError("GROQ_API_KEY not set.")
    client = Groq(api_key=api_key)
    full = [{"role": "system", "content": system}] + messages
    if len(full) > 13:
        full = [full[0]] + full[-12:]
    resp = client.chat.completions.create(
        model=model,
        messages=full,
        temperature=0.2,
        max_tokens=max_tokens,
    )
    return resp.choices[0].message.content or ""


def _call_gemini(system: str, messages: list[dict], max_tokens: int) -> str:
    from google import genai
    from google.genai import types

    api_key = os.environ.get("GEMINI_API_KEY", "")
    if not api_key:
        raise RuntimeError("GEMINI_API_KEY not set.")
    model = os.environ.get("GEMINI_MODEL", "gemini-2.5-flash")
    client = genai.Client(api_key=api_key)

    formatted = []
    for m in messages:
        role = "user" if m["role"] == "user" else "model"
        formatted.append(types.Content(role=role, parts=[types.Part(text=m["content"])]))

    resp = client.models.generate_content(
        model=model,
        contents=formatted,
        config=types.GenerateContentConfig(
            system_instruction=system,
            temperature=0.2,
            max_output_tokens=max_tokens,
        ),
    )
    return (resp.text or "").strip()


def _call_deepseek(system: str, messages: list[dict], max_tokens: int) -> str:
    from openai import OpenAI
    api_key = os.environ.get("DEEPSEEK_API_KEY", "")
    if not api_key:
        raise RuntimeError("DEEPSEEK_API_KEY not set.")
    model = os.environ.get("DEEPSEEK_MODEL", "deepseek-chat")
    client = OpenAI(api_key=api_key, base_url="https://api.deepseek.com")
    full = [{"role": "system", "content": system}] + messages
    resp = client.chat.completions.create(
        model=model,
        messages=full,
        temperature=0.2,
        max_tokens=max_tokens,
    )
    return resp.choices[0].message.content or ""


# ── Public interface ──────────────────────────────────────────────────

def call_llm(
    system: str,
    messages: list[dict],
    provider: Optional[str] = None,
    model: Optional[str] = None,
    max_tokens: int = 4096,
) -> str:
    """
    Call the LLM with automatic fallback chain.

    Provider order (if not forced): env GOD_LLM_PROVIDER → groq → gemini → deepseek
    """
    provider = (provider or os.environ.get("GOD_LLM_PROVIDER", "groq")).lower()

    # Build fallback chain starting from chosen provider
    all_providers = ["groq", "gemini", "deepseek"]
    chain = [provider] + [p for p in all_providers if p != provider]

    last_error: Exception = RuntimeError("No provider configured.")

    for prov in chain:
        for attempt in range(3):
            try:
                if prov == "groq":
                    resolved = _resolve_groq(model)
                    return _call_groq(system, messages, resolved, max_tokens)
                elif prov == "gemini":
                    if not os.environ.get("GEMINI_API_KEY"):
                        break  # skip — not configured
                    return _call_gemini(system, messages, max_tokens)
                elif prov == "deepseek":
                    if not os.environ.get("DEEPSEEK_API_KEY"):
                        break
                    return _call_deepseek(system, messages, max_tokens)

            except Exception as exc:
                last_error = exc
                err = str(exc).lower()

                # Daily/quota limit → jump to next provider immediately
                if "day" in err and ("rate" in err or "limit" in err or "quota" in err):
                    print(f"  [{prov} daily limit] → trying next provider...")
                    break

                # RPM rate limit → backoff and retry same provider
                if "429" in err or "rate" in err or "413" in err:
                    wait = 25 * (attempt + 1)
                    print(f"  [{prov} rate limit] waiting {wait}s (attempt {attempt+1}/3)...")
                    time.sleep(wait)
                    if len(messages) > 4:
                        messages = messages[:1] + messages[-3:]
                    continue

                # Other errors — surface immediately (misconfiguration, etc.)
                if attempt >= 2:
                    print(f"  [{prov}] failed: {exc}")
                    break
                time.sleep(3)

    raise RuntimeError(f"All providers exhausted. Last error: {last_error}")
